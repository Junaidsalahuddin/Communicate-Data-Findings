# Prosper Loan Data Exploration

## by (Junaid Salahuddin)

## Dataset

Investigation and information discoveries were performed on the Prosper loan dataset. The dataset comprises of around 113,000 records (loans). There are 81 sepparate (highlights) sections in the dataset. I picked a subset of them to discover any connections between the interest rate of the loans.

## Summary of Findings

I expected that the different diverse acknowledge hazard scores related for each credit and income and debt related highlights would be the most worthwhile in this examination. My underlying instinct was right and most of the highlights picked were connected with the financing cost segments, with ProsperRating (Alpha) or it's numeric variation 'ProsperRating (numeric)' being profoundly corresponded. 

The others weren't as associated, and I looked further into why the restrictive 'ProsperScore' wasn't as connected and turned out that when taking a gander at multivariate connections that the qualities for the 'ProsperScore' segment were appropriated acorss all degrees of the 'ProsperRating(s)'. This means an advance with a low/wrose 'ProsperRating' could have a decent/high 'ProsperScore' and the other way around. This suggests other measures not investigated in the examination are utilized to decide the 'ProsperScore' and it would be a decent spot for future anaylsis to start. 

Another variable that I however would be connected was the 'DebtToIncomeRatio' yet it ended up having a low relationship to the loan fee sections. The conveyance likewise contained outrageous exceptions and while investigating it's dispersion the x-hub must be changed in accordance with see a typically appropriated histogram between estimations of '0' and '1.5' with a left slant. 

In investigating how the interest rate of a loan is influenced by the loans Term(length of advance) I found that under each 'ProsperRating' shorter term advances had a lower loan fee. Obviously those with a higher/better 'ProsperRating' had a lower interest rate.

## Key Insights for Presentation

In the event that you need a lower interest rate on an loan from Prosper you ought to have a low credit hazard, ie. a higher/better 'ProsperRating [Alpha/numeric]' and consider taking out a 12 more than three year or 36 more than multi month long haul loans.
## Resources

* matplitlib documentation
* seaborn documentation
* pandas documenation
* Udacity Instructions

